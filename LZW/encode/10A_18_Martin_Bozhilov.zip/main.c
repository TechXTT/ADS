
// Initialize table with single character strings
// P = first input character
// WHILE not end of input stream
//  C = next input character
//  IF P + C is in the string table
//    P = P + C
//  ELSE
//    output the code for P
//  add P + C to the string table
//    P = C
//  END WHILE
// output code for P

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int encode(char *str, int *output)
{
    char *table[300];
    int table_size = 255;
    int output_size = 0;

    for (int i = 0; i < 256; i++)
    {
        table[i] = (char *)malloc(sizeof(char) * 2);
        table[i][0] = (char)i;
        table[i][1] = '\0';
    }

    char *p = (char *)malloc(sizeof(char) * 20);
    char c = str[0];
    strcpy(p, &c);
    for (int i = 1; i < strlen(str); i++)
    {
        c = str[i];
        char *temp = (char *)malloc(sizeof(char) * (strlen(p) + 2));
        strcpy(temp, p);
        strcat(temp, &c);
        for (int j = 0; j < table_size; j++)
        {
            if (strcmp(table[j], temp) == 0)
            {
                strcpy(p, temp);
                break;
            }
            else if (j == table_size - 1)
            {
                if (strlen(p) == 1)
                {
                    output[output_size] = (int)p[0];
                    output_size++;
                }
                else
                {
                    output[output_size] = table_size++;
                    output_size++;
                    table[table_size] = (char *)malloc(sizeof(char) * (strlen(p) + 1));
                    strcpy(table[table_size], p);
                }
                strcpy(p, &c);
            }
        }
    }
    if (strlen(p) == 1)
    {
        output[output_size] = (int)p[0];
        output_size++;
    }
    else
    {
        output[output_size] = table_size++;
        output_size++;
        table[table_size] = (char *)malloc(sizeof(char) * (strlen(p) + 1));
        strcpy(table[table_size], p);
    }
    return output_size;
}

int main()
{
    char *str = "WYS*WYGWYS*WYSWYSG";
    int *output = (int *)malloc(sizeof(int) * strlen(str));
    int size = encode(str, output);
    for (int i = 0; i < size; i++)
    {
        printf("%d ", output[i]);
    }
}